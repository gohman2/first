<?php
$host = "localhost";
$user = "root";
$password = "";
$database = "testphp";
$db = mysqli_connect($host, $user, $password, $database) or die (mysqli_conect_error());

