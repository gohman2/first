<?php
require_once 'config.php';
require_once 'libs.php';


    if($_POST['regionval']){
        $idRegion = $_POST['regionval'];
        $citys = selectCity ($idRegion);
    exit ($citys);
}
    if($_POST['cityval']){
        $idCity = $_POST['cityval'];
        $areas = selectArea ($idCity);
    exit ($areas);
}
    if($_POST['email']){
        $email = $_POST['email'];
        $msg =  checkEmail ($email);
         exit ($msg);
        
    }


?>
<head>
<title>Форма</title>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.1/jquery.min.js"></script>
<link href="style.css" rel="stylesheet">
<link href="chosen/chosen.css" rel="stylesheet">
</head>
<?php
$regions = selectRegion();
require_once 'viev.tpl';
?>
  <script src="chosen/chosen.jquery.js" type="text/javascript"></script>
  <script src="mainjs.js"></script>
  <script type="text/javascript">
    var config = {
      '.chosen-select'           : {},
      '.chosen-select-deselect'  : {allow_single_deselect:true},
      '.chosen-select-no-single' : {disable_search_threshold:10},
      '.chosen-select-no-results': {no_results_text:'Oops, nothing found!'},
      '.chosen-select-width'     : {width:"95%"}
    }
    for (var selector in config) {
      $(selector).chosen(config[selector]);
    }
  </script>