$(document).ready( function(){
    $("#region").change(function(){
        var regionval = $("#region").val();
        selectCity(regionval);
    });
    
    $("#city").change(function(){
      var cityval = $("#city").val();  
       selectArea(cityval);
    });
});


function selectCity(regionval){
    var city = $("#city");
    $("#divCity, #divArea").hide();
    clear(city);
    clear($("#area"));
    
    if(regionval > 0){
       
        $("#divCity").fadeIn("slow");
        city.attr("disabled", false);
        city.load(
                "index.php",
                {regionval:regionval}
                );
    }
}

function selectArea(cityval){
      var area = $("#area");
      $("#divArea").hide();
      clear(area);
      if(cityval > 0){
           $("#divArea").fadeIn("slow");
           area.attr("disabled", false);
           $("#saveSubmith").attr("disabled", false);
           area.load(
                "index.php",
                {cityval:cityval}
                );
           
          
      }
}

function clear (val){
    val.empty();
    val.attr("disabled", true);
}

$(document).ready(function(){
      
    
    $("#email").focus(function(){
         $("#email").next().empty();
    })
    $("#email").blur(function(){
        var email = $("#email").val();
        if(email != ""){
               
           $.ajax({
                url:'index.php',
                type:'POST',
                data: {email:email},
                success:function(res){
                     $("#email").next().text(res);
                     if(res == "ok"){
                     
                     }
                },
                error: function(){
                    $("#email").next().text("Ошибка!");
                }
                
                
            });
        }else{
            $("#email").next().text("Заполните поле!");
        
        }
    });
    
     
    $("#fio").focus(function(){
         $("#fio").next().empty();
    })
     $("#fio").blur(function(){
        var fio = $("#fio").val();
        if(fio != ""){
            $("#fio").next().text("ok!");
            
            
      }else{
            $("#fio").next().text("Заполните поле!");
            
        } });
       
  
});


	function call() {
 	  var msg   = $('#formx').serialize();
        $.ajax({
          type: 'POST',
          url: 'res.php',
          data: msg,
          success: function(data) {
            $('#results').html(data);
          },
          error:  function(xhr, str){
	    alert('Возникла ошибка: ' + xhr.responseCode);
          }
        });
 
    }