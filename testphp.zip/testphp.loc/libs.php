<?php

function selectRegion(){
    global $db;
    $regions = array();
    $sql = "SELECT tkt.ter_name , tkt.ter_id FROM t_koatuu_tree tkt WHERE tkt.ter_pid IS NULL AND tkt.ter_type_id = 0";
    if($result = mysqli_query($db,$sql)){
        while($row = mysqli_fetch_assoc($result)){
               $regions[] = $row;  
        }
        return $regions;
    }else{
        return false;
    }
}

function selectCity ($idRegion){
    global $db;
    $return = "";
    $sql = "SELECT tkt.ter_name , tkt.ter_id FROM t_koatuu_tree tkt WHERE tkt.ter_pid = $idRegion AND (tkt.ter_type_id = 1 or tkt.ter_type_id = 2)";
    if($result = mysqli_query($db,$sql)){
        $return = "<option value='0'>--Выберите город / район--</option>";
        while($row = mysqli_fetch_assoc($result)){
            $return.= "<option value='{$row['ter_id']}'> {$row['ter_name']}</option>";
        }
        return $return;
    }else{
        return false;
    }
    
}

function selectArea ($idCity){
    global $db;
    $return = "";
    $sql = "SELECT tkt.ter_name , tkt.ter_id FROM t_koatuu_tree tkt WHERE tkt.ter_pid = $idCity 
        AND (tkt.ter_type_id = 3 or tkt.ter_type_id = 4 or tkt.ter_type_id = 4 or tkt.ter_type_id = 6)";
    if($result = mysqli_query($db,$sql)){
        $return = "<option value='0'>--Выберите район города / населеный пункт--</option>";
        while($row = mysqli_fetch_assoc($result)){
            $return.= "<option value='{$row['ter_id']}'> {$row['ter_name']}</option>";
        }
        return $return;
    }else{
        return false;
    }
    
}

function checkEmail ($email){
    global $db;
    $msg = "";
    $sql = "SELECT name,email,territory FROM users WHERE email = '$email'";
    $result = mysqli_query($db,$sql);
    if(mysqli_num_rows($result)){
        $row = mysqli_fetch_assoc($result);
          $msg = "Email занят:Имя - ".$row['name'].",email - ".$row['email'].",адресс - ".$row['territory'];
          return $msg;
    }else{
        return "ok";
        
    }
    
}

 

function saveUser ($fio,$email,$regionId,$cityId,$areaId = '0'){
    global $db;
    $region = "";
    $city = "";
    $area = "";
    $query_region = "SELECT tkt.ter_name  FROM t_koatuu_tree tkt WHERE tkt.ter_id = $regionId";
    $res_r = mysqli_query($db,  $query_region);
    $row_r = mysqli_fetch_assoc($res_r);
    $region = $row_r['ter_name'];
    
    $query_city = "SELECT tkt.ter_name FROM t_koatuu_tree tkt WHERE tkt.ter_id = $cityId";
    $res_c = mysqli_query($db,  $query_city);
    $row_c = mysqli_fetch_assoc($res_c);
    $city = $row_c['ter_name'];
    if($areaId > 0){
        $query_area = "SELECT tkt.ter_name FROM t_koatuu_tree tkt WHERE tkt.ter_id = $areaId";
        $res_a = mysqli_query($db,  $query_area);
        $row_a = mysqli_fetch_assoc($res_a);
        $area = $row_a['ter_name'];
    }else{
        $area="--";
    }
    
    $address = $region.",". $city.",".$area;
    $query_insert = "INSERT INTO users (name, email, territory) VALUES ('$fio','$email','$address')";
    
    if($res = mysqli_query($db,$query_insert)){
        return true;
        
    }else{
       return FALSE;
    }
    
    
    
    
}


function cleanStr($data){
	return trim(strip_tags($data));

}