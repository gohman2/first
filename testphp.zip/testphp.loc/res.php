<?php

require_once 'config.php';
require_once 'libs.php';


$fio =      cleanStr($_POST['fio']);
$email =    cleanStr($_POST['email']);
$regionId = cleanStr($_POST['region']);
$cityId =   cleanStr($_POST['city']);
$areaId =   cleanStr($_POST['area']);


if(saveUser ($fio,$email,$regionId,$cityId,$areaId)){
    echo "Юзер сохранен!";
    echo '<script type="text/javascript">setTimeout(function(){window.top.location="index.php"} , 1000);</script>';
}else{
    echo "Ошибка";
}


